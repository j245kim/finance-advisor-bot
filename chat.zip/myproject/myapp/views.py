from django.shortcuts import render
from django.http import JsonResponse
import pandas as pd
import json
import base64


# Create your views here.

def GivemeJson(request,input_string):

    answer = int(input_string)

    if answer >= 26:
        response = '공격 투자형'
    elif answer >= 21:
        response = '적극 투자형'
    elif answer >= 16:
        response = '적극 투자형'
    elif answer >= 11:
        response = '적극 투자형'
    else :
        response = '안정형'

    return JsonResponse({'type':f'{response}'})